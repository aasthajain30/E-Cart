package com.javacart.services;

import com.javacart.models.Product;
import com.javacart.exceptions.ProductNotFoundException;

import java.math.BigDecimal;
import java.util.List;

public interface ProductService {
    List<Product> getAllProducts();
    Product getProductById(Long id) throws ProductNotFoundException;
    List<Product> getProductsByCategory(String category);
    List<Product> searchProducts(String keyword);
    List<Product> getProductsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice);
    Product addProduct(Product product);
    Product updateProduct(Product product) throws ProductNotFoundException;
    void deleteProduct(Long id) throws ProductNotFoundException;
    boolean updateStock(Long productId, Integer quantity) throws ProductNotFoundException;
    List<Product> getProductsSortedByPrice(boolean ascending);
    List<Product> getProductsSortedByName();
}
