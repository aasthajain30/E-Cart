package com.javacart.services.impl;

import com.javacart.database.DatabaseManager;
import com.javacart.models.User;
import com.javacart.services.AuthService;
import com.javacart.exceptions.UserNotFoundException;
import com.javacart.utils.PasswordUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.function.Supplier;

public class AuthServiceImpl implements AuthService {
    private User currentUser;
    
    @Override
    public User login(String username, String password) throws UserNotFoundException {
        String sql = "SELECT * FROM users WHERE username = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String storedPassword = rs.getString("password");
                
                Supplier<Boolean> passwordCheck = () -> PasswordUtil.verifyPassword(password, storedPassword);
                
                if (passwordCheck.get()) {
                    currentUser = mapResultSetToUser(rs);
                    return currentUser;
                } else {
                    throw new UserNotFoundException("Invalid username or password");
                }
            } else {
                throw new UserNotFoundException("Invalid username or password");
            }
        } catch (SQLException e) {
            System.err.println("Error during login: " + e.getMessage());
            throw new UserNotFoundException("Login failed: " + e.getMessage());
        }
    }
    
    @Override
    public User register(String username, String email, String password, String role) {
        String sql = "INSERT INTO users (username, email, password, role, created_at) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            String hashedPassword = PasswordUtil.hashPassword(password);
            
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, hashedPassword);
            stmt.setString(4, role);
            stmt.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        User user = new User(username, email, hashedPassword, role);
                        user.setId(generatedKeys.getLong(1));
                        user.setCreatedAt(LocalDateTime.now());
                        return user;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error during registration: " + e.getMessage());
            throw new RuntimeException("Registration failed: " + e.getMessage(), e);
        }
        
        return null;
    }
    
    @Override
    public void logout() {
        Optional.ofNullable(currentUser)
            .ifPresent(user -> System.out.println("User " + user.getUsername() + " logged out"));
        currentUser = null;
    }
    
    @Override
    public Optional<User> getCurrentUser() {
        return Optional.ofNullable(currentUser);
    }
    
    @Override
    public boolean isLoggedIn() {
        return getCurrentUser().isPresent();
    }
    
    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setId(rs.getLong("id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setRole(rs.getString("role"));
        
        Optional.ofNullable(rs.getTimestamp("created_at"))
            .ifPresent(timestamp -> user.setCreatedAt(timestamp.toLocalDateTime()));
        
        return user;
    }
}
