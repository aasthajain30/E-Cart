package com.javacart.services.impl;

import com.javacart.database.DatabaseManager;
import com.javacart.models.Product;
import com.javacart.services.ProductService;
import com.javacart.exceptions.ProductNotFoundException;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ProductServiceImpl implements ProductService {
    
    @Override
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE stock_quantity > 0";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                products.add(mapResultSetToProduct(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching products: " + e.getMessage());
        }
        
        return products;
    }
    
    @Override
    public Product getProductById(Long id) throws ProductNotFoundException {
        String sql = "SELECT * FROM products WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToProduct(rs);
            } else {
                throw new ProductNotFoundException("Product with ID " + id + " not found");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching product: " + e.getMessage());
            throw new ProductNotFoundException("Error fetching product: " + e.getMessage());
        }
    }
    
    @Override
    public List<Product> getProductsByCategory(String category) {
        return getAllProducts().stream()
                .filter(product -> product.getCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Product> searchProducts(String keyword) {
        return getAllProducts().stream()
                .filter(product -> 
                    product.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                    product.getDescription().map(desc -> desc.toLowerCase().contains(keyword.toLowerCase())).orElse(false) ||
                    product.getCategory().toLowerCase().contains(keyword.toLowerCase())
                )
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Product> getProductsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice) {
        return getAllProducts().stream()
                .filter(product -> 
                    product.getPrice().compareTo(minPrice) >= 0 && 
                    product.getPrice().compareTo(maxPrice) <= 0
                )
                .collect(Collectors.toList());
    }
    
    @Override
    public Product addProduct(Product product) {
        String sql = "INSERT INTO products (name, description, price, category, stock_quantity, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, product.getName());
            stmt.setString(2, product.getDescription().orElse(null));
            stmt.setBigDecimal(3, product.getPrice());
            stmt.setString(4, product.getCategory());
            stmt.setInt(5, product.getStockQuantity());
            stmt.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    product.setId(generatedKeys.getLong(1));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error adding product: " + e.getMessage());
        }
        
        return product;
    }
    
    @Override
    public Product updateProduct(Product product) throws ProductNotFoundException {
        String sql = "UPDATE products SET name = ?, description = ?, price = ?, category = ?, stock_quantity = ?, updated_at = ? WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, product.getName());
            stmt.setString(2, product.getDescription().orElse(null));
            stmt.setBigDecimal(3, product.getPrice());
            stmt.setString(4, product.getCategory());
            stmt.setInt(5, product.getStockQuantity());
            stmt.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setLong(7, product.getId());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new ProductNotFoundException("Product with ID " + product.getId() + " not found");
            }
        } catch (SQLException e) {
            System.err.println("Error updating product: " + e.getMessage());
            throw new ProductNotFoundException("Error updating product: " + e.getMessage());
        }
        
        return product;
    }
    
    @Override
    public void deleteProduct(Long id) throws ProductNotFoundException {
        String sql = "DELETE FROM products WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new ProductNotFoundException("Product with ID " + id + " not found");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting product: " + e.getMessage());
            throw new ProductNotFoundException("Error deleting product: " + e.getMessage());
        }
    }
    
    @Override
    public boolean updateStock(Long productId, Integer quantity) throws ProductNotFoundException {
        String sql = "UPDATE products SET stock_quantity = stock_quantity - ?, updated_at = ? WHERE id = ? AND stock_quantity >= ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, quantity);
            stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setLong(3, productId);
            stmt.setInt(4, quantity);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating stock: " + e.getMessage());
            throw new ProductNotFoundException("Error updating stock: " + e.getMessage());
        }
    }
    
    @Override
    public List<Product> getProductsSortedByPrice(boolean ascending) {
        return getAllProducts().stream()
                .sorted(ascending ? 
                    Comparator.comparing(Product::getPrice) : 
                    Comparator.comparing(Product::getPrice).reversed())
                .collect(Collectors.toList());
    }
    
    @Override
    public List<Product> getProductsSortedByName() {
        return getAllProducts().stream()
                .sorted(Comparator.comparing(Product::getName))
                .collect(Collectors.toList());
    }
    
    private Product mapResultSetToProduct(ResultSet rs) throws SQLException {
        Product product = new Product();
        product.setId(rs.getLong("id"));
        product.setName(rs.getString("name"));
        Optional<String> description = Optional.ofNullable(rs.getString("description"));
        product.setDescription(description);
        product.setPrice(rs.getBigDecimal("price"));
        product.setCategory(rs.getString("category"));
        product.setStockQuantity(rs.getInt("stock_quantity"));
        product.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        product.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
        return product;
    }
}
