package com.javacart.services.impl;

import com.javacart.database.DatabaseManager;
import com.javacart.models.Cart;
import com.javacart.models.Product;
import com.javacart.services.CartService;
import com.javacart.services.ProductService;
import com.javacart.exceptions.OutOfStockException;
import com.javacart.exceptions.ProductNotFoundException;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CartServiceImpl implements CartService {
    private final ProductService productService = new ProductServiceImpl();
    
    @Override
    public void addToCart(Long userId, Long productId, Integer quantity) throws ProductNotFoundException, OutOfStockException {
        // Check if product exists and has enough stock
        Product product = productService.getProductById(productId);
        if (product.getStockQuantity() < quantity) {
            throw new OutOfStockException("Not enough stock available. Available: " + product.getStockQuantity());
        }
        
        // Check if item already exists in cart
        String checkSql = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
        String insertSql = "INSERT INTO cart (user_id, product_id, quantity, created_at) VALUES (?, ?, ?, ?)";
        String updateSql = "UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?";
        
        try (Connection conn = DatabaseManager.getConnection()) {
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setLong(1, userId);
            checkStmt.setLong(2, productId);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                // Update existing cart item
                int currentQuantity = rs.getInt("quantity");
                if (product.getStockQuantity() < currentQuantity + quantity) {
                    throw new OutOfStockException("Not enough stock available. Available: " + product.getStockQuantity() + ", Requested: " + (currentQuantity + quantity));
                }
                
                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                updateStmt.setInt(1, quantity);
                updateStmt.setLong(2, userId);
                updateStmt.setLong(3, productId);
                updateStmt.executeUpdate();
            } else {
                // Insert new cart item
                PreparedStatement insertStmt = conn.prepareStatement(insertSql);
                insertStmt.setLong(1, userId);
                insertStmt.setLong(2, productId);
                insertStmt.setInt(3, quantity);
                insertStmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
                insertStmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.err.println("Error adding to cart: " + e.getMessage());
        }
    }
    
    @Override
    public void removeFromCart(Long userId, Long productId) {
        String sql = "DELETE FROM cart WHERE user_id = ? AND product_id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, userId);
            stmt.setLong(2, productId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error removing from cart: " + e.getMessage());
        }
    }
    
    @Override
    public void updateCartItemQuantity(Long userId, Long productId, Integer quantity) throws OutOfStockException {
        try {
            Product product = productService.getProductById(productId);
            if (product.getStockQuantity() < quantity) {
                throw new OutOfStockException("Not enough stock available. Available: " + product.getStockQuantity());
            }
            
            String sql = "UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?";
            
            try (Connection conn = DatabaseManager.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                
                stmt.setInt(1, quantity);
                stmt.setLong(2, userId);
                stmt.setLong(3, productId);
                stmt.executeUpdate();
            }
        } catch (ProductNotFoundException e) {
            System.err.println("Product not found: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Error updating cart quantity: " + e.getMessage());
        }
    }
    
    @Override
    public List<Cart> getCartItems(Long userId) {
        List<Cart> cartItems = new ArrayList<>();
        String sql = "SELECT c.*, p.* FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Cart cart = new Cart();
                cart.setId(rs.getLong("c.id"));
                cart.setUserId(rs.getLong("c.user_id"));
                cart.setProductId(rs.getLong("c.product_id"));
                cart.setQuantity(rs.getInt("c.quantity"));
                cart.setCreatedAt(rs.getTimestamp("c.created_at").toLocalDateTime());
                
                Product product = new Product();
                product.setId(rs.getLong("p.id"));
                product.setName(rs.getString("p.name"));
                product.setDescription(rs.getString("p.description"));
                product.setPrice(rs.getBigDecimal("p.price"));
                product.setCategory(rs.getString("p.category"));
                product.setStockQuantity(rs.getInt("p.stock_quantity"));
                
                cart.setProduct(product);
                cartItems.add(cart);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching cart items: " + e.getMessage());
        }
        
        return cartItems;
    }
    
    @Override
    public BigDecimal getCartTotal(Long userId) {
        return getCartItems(userId).stream()
                .map(Cart::getTotalPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    @Override
    public void clearCart(Long userId) {
        String sql = "DELETE FROM cart WHERE user_id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error clearing cart: " + e.getMessage());
        }
    }
    
    @Override
    public int getCartItemCount(Long userId) {
        return getCartItems(userId).stream()
                .mapToInt(Cart::getQuantity)
                .sum();
    }
}
