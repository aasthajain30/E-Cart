package com.javacart.services.impl;

import com.javacart.database.DatabaseManager;
import com.javacart.models.Cart;
import com.javacart.models.Order;
import com.javacart.models.OrderItem;
import com.javacart.models.Product;
import com.javacart.services.OrderService;
import com.javacart.services.CartService;
import com.javacart.services.ProductService;
import com.javacart.exceptions.OutOfStockException;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class OrderServiceImpl implements OrderService {
    private final CartService cartService = new CartServiceImpl();
    private final ProductService productService = new ProductServiceImpl();
    private final ReentrantLock stockLock = new ReentrantLock();
    
    @Override
    public Order createOrder(Long userId) throws OutOfStockException {
        List<Cart> cartItems = cartService.getCartItems(userId);
        if (cartItems.isEmpty()) {
            throw new IllegalStateException("Cart is empty");
        }
        
        BigDecimal totalAmount = cartService.getCartTotal(userId);
        Order order = new Order(userId, totalAmount, "PENDING");
        
        try (Connection conn = DatabaseManager.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // Create order
                String orderSql = "INSERT INTO orders (user_id, total_amount, status, created_at) VALUES (?, ?, ?, ?)";
                PreparedStatement orderStmt = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
                orderStmt.setLong(1, order.getUserId());
                orderStmt.setBigDecimal(2, order.getTotalAmount());
                orderStmt.setString(3, order.getStatus());
                orderStmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
                
                orderStmt.executeUpdate();
                ResultSet generatedKeys = orderStmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    order.setId(generatedKeys.getLong(1));
                }
                
                // Create order items and update stock
                String orderItemSql = "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)";
                PreparedStatement orderItemStmt = conn.prepareStatement(orderItemSql);
                
                for (Cart cartItem : cartItems) {
                    Product product = cartItem.getProduct().orElse(null);
                    if (product == null) {
                        throw new OutOfStockException("Product not found in cart item");
                    }
                    
                    // Check and update stock
                    boolean stockUpdated = productService.updateStock(cartItem.getProductId(), cartItem.getQuantity());
                    if (!stockUpdated) {
                        throw new OutOfStockException("Insufficient stock for product: " + product.getName());
                    }
                    
                    // Create order item
                    orderItemStmt.setLong(1, order.getId());
                    orderItemStmt.setLong(2, cartItem.getProductId());
                    orderItemStmt.setInt(3, cartItem.getQuantity());
                    orderItemStmt.setBigDecimal(4, product.getPrice());
                    orderItemStmt.addBatch();
                }
                
                orderItemStmt.executeBatch();
                
                // Clear cart
                cartService.clearCart(userId);
                
                // Update order status
                updateOrderStatus(order.getId(), "COMPLETED");
                order.setStatus("COMPLETED");
                
                conn.commit();
            } catch (Exception e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.err.println("Error creating order: " + e.getMessage());
            throw new RuntimeException("Error creating order: " + e.getMessage());
        }
        
        return order;
    }
    
    @Override
    public List<Order> getOrdersByUserId(Long userId) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Order order = mapResultSetToOrder(rs);
                order.setOrderItems(getOrderItems(order.getId()));
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching user orders: " + e.getMessage());
        }
        
        return orders;
    }
    
    @Override
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Order order = mapResultSetToOrder(rs);
                order.setOrderItems(getOrderItems(order.getId()));
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching all orders: " + e.getMessage());
        }
        
        return orders;
    }
    
    @Override
    public Order getOrderById(Long orderId) {
        String sql = "SELECT * FROM orders WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Order order = mapResultSetToOrder(rs);
                order.setOrderItems(getOrderItems(order.getId()));
                return order;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching order: " + e.getMessage());
        }
        
        return null;
    }
    
    @Override
    public void updateOrderStatus(Long orderId, String status) {
        String sql = "UPDATE orders SET status = ? WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            stmt.setLong(2, orderId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating order status: " + e.getMessage());
        }
    }
    
    @Override
    public void processOrderConcurrently(Long userId) throws OutOfStockException {
        stockLock.lock();
        try {
            createOrder(userId);
        } finally {
            stockLock.unlock();
        }
    }
    
    private List<OrderItem> getOrderItems(Long orderId) {
        List<OrderItem> orderItems = new ArrayList<>();
        String sql = "SELECT oi.*, p.name, p.description FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                OrderItem orderItem = new OrderItem();
                orderItem.setId(rs.getLong("id"));
                orderItem.setOrderId(rs.getLong("order_id"));
                orderItem.setProductId(rs.getLong("product_id"));
                orderItem.setQuantity(rs.getInt("quantity"));
                orderItem.setUnitPrice(rs.getBigDecimal("unit_price"));
                
                Product product = new Product();
                product.setId(rs.getLong("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                orderItem.setProduct(product);
                
                orderItems.add(orderItem);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching order items: " + e.getMessage());
        }
        
        return orderItems;
    }
    
    private Order mapResultSetToOrder(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setId(rs.getLong("id"));
        order.setUserId(rs.getLong("user_id"));
        order.setTotalAmount(rs.getBigDecimal("total_amount"));
        order.setStatus(rs.getString("status"));
        order.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return order;
    }
}
