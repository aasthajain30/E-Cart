package com.javacart.services;

import com.javacart.models.Cart;
import com.javacart.exceptions.OutOfStockException;
import com.javacart.exceptions.ProductNotFoundException;

import java.math.BigDecimal;
import java.util.List;

public interface CartService {
    void addToCart(Long userId, Long productId, Integer quantity) throws ProductNotFoundException, OutOfStockException;
    void removeFromCart(Long userId, Long productId);
    void updateCartItemQuantity(Long userId, Long productId, Integer quantity) throws OutOfStockException;
    List<Cart> getCartItems(Long userId);
    BigDecimal getCartTotal(Long userId);
    void clearCart(Long userId);
    int getCartItemCount(Long userId);
}
