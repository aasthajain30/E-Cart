package com.javacart.services;

import com.javacart.models.User;
import com.javacart.exceptions.UserNotFoundException;
import java.util.Optional;

public interface AuthService {
    User login(String username, String password) throws UserNotFoundException;
    User register(String username, String email, String password, String role);
    void logout();
    
    Optional<User> getCurrentUser();
    boolean isLoggedIn();
    
    default boolean isAdmin() {
        return getCurrentUser()
            .map(User::getRole)
            .filter("ADMIN"::equals)
            .isPresent();
    }
    
    default boolean isCustomer() {
        return getCurrentUser()
            .map(User::getRole)
            .filter("CUSTOMER"::equals)
            .isPresent();
    }
    
    default String getCurrentUsername() {
        return getCurrentUser()
            .map(User::getUsername)
            .orElse("Guest");
    }
    
    default Long getCurrentUserId() {
        return getCurrentUser()
            .map(User::getId)
            .orElse(null);
    }
}
