package com.javacart;

import com.javacart.database.DatabaseManager;
import com.javacart.models.User;
import com.javacart.services.impl.AuthServiceImpl;
import com.javacart.services.impl.ProductServiceImpl;
import com.javacart.services.impl.CartServiceImpl;
import com.javacart.services.impl.OrderServiceImpl;
import com.javacart.utils.ConsoleUI;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.function.Consumer;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static AuthServiceImpl authService;
    private static ProductServiceImpl productService;
    private static CartServiceImpl cartService;
    private static OrderServiceImpl orderService;
    private static ConsoleUI ui;
    
    public static void main(String[] args) {
        try {
            initializeServices();
            
            System.out.println("=== Welcome to JavaCart E-Commerce System (Java 8) ===");
            
            runApplication();
            
        } catch (SQLException e) {
            handleError("Database initialization failed", e);
        } catch (Exception e) {
            handleError("Application error", e);
        }
    }
    
    private static void initializeServices() throws SQLException {
        DatabaseManager.initializeDatabase();
        authService = new AuthServiceImpl();
        productService = new ProductServiceImpl();
        cartService = new CartServiceImpl();
        orderService = new OrderServiceImpl();
        ui = new ConsoleUI();
    }
    
    private static void runApplication() {
        while (true) {
            authService.getCurrentUser()
                .map(user -> {
                    if ("ADMIN".equals(user.getRole())) {
                        showAdminMenu();
                    } else {
                        showCustomerMenu();
                    }
                    return user;
                })
                .orElseGet(() -> {
                    showLoginMenu();
                    return null;
                });
        }
    }
    
    private static void handleError(String message, Exception e) {
        Consumer<String> errorLogger = msg -> System.err.println(msg + ": " + e.getMessage());
        errorLogger.accept(message);
    }
    
    private static void showLoginMenu() {
        System.out.println("\n1. Login");
        System.out.println("2. Register");
        System.out.println("3. Exit");
        System.out.print("Choose option: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline
        
        Runnable[] menuActions = {
            () -> ui.handleLogin(authService),
            () -> ui.handleRegistration(authService),
            () -> {
                System.out.println("Thank you for using JavaCart!");
                System.exit(0);
            }
        };
        
        if (choice >= 1 && choice <= 3) {
            menuActions[choice - 1].run();
        } else {
            System.out.println("Invalid option!");
        }
    }
    
    private static void showAdminMenu() {
        System.out.println("\n=== Admin Dashboard ===");
        System.out.println("1. View All Products");
        System.out.println("2. Add Product");
        System.out.println("3. Update Product");
        System.out.println("4. Delete Product");
        System.out.println("5. View All Orders");
        System.out.println("6. Simulate Concurrent Orders");
        System.out.println("7. Logout");
        System.out.print("Choose option: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine();
        
        executeAdminAction(choice);
    }
    
    private static void executeAdminAction(int choice) {
        switch (choice) {
            case 1:
                ui.displayProducts(productService.getAllProducts());
                break;
            case 2:
                ui.handleAddProduct(productService);
                break;
            case 3:
                ui.handleUpdateProduct(productService);
                break;
            case 4:
                ui.handleDeleteProduct(productService);
                break;
            case 5:
                ui.displayOrders(orderService.getAllOrders());
                break;
            case 6:
                ui.simulateConcurrentOrders(orderService, productService);
                break;
            case 7:
                authService.logout();
                break;
            default:
                System.out.println("Invalid option!");
        }
    }
    
    private static void showCustomerMenu() {
        System.out.println("\n=== Customer Dashboard ===");
        System.out.println("1. Browse Products");
        System.out.println("2. Search Products");
        System.out.println("3. View Cart");
        System.out.println("4. Add to Cart");
        System.out.println("5. Remove from Cart");
        System.out.println("6. Checkout");
        System.out.println("7. View Order History");
        System.out.println("8. Logout");
        System.out.print("Choose option: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine();
        
        executeCustomerAction(choice);
    }
    
    private static void executeCustomerAction(int choice) {
        authService.getCurrentUser().ifPresent(user -> {
            Long userId = user.getId();
            
            switch (choice) {
                case 1:
                    ui.handleBrowseProducts(productService);
                    break;
                case 2:
                    ui.handleSearchProducts(productService);
                    break;
                case 3:
                    ui.displayCart(cartService, userId);
                    break;
                case 4:
                    ui.handleAddToCart(cartService, productService, userId);
                    break;
                case 5:
                    ui.handleRemoveFromCart(cartService, userId);
                    break;
                case 6:
                    ui.handleCheckout(cartService, orderService, userId);
                    break;
                case 7:
                    ui.displayOrders(orderService.getOrdersByUserId(userId));
                    break;
                case 8:
                    authService.logout();
                    break;
                default:
                    System.out.println("Invalid option!");
            }
        });
    }
}
