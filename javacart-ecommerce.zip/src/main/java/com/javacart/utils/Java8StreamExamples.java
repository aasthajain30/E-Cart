package com.javacart.utils;

import com.javacart.models.Product;
import com.javacart.models.Cart;
import com.javacart.models.Order;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;

/**
 * Utility class demonstrating Java 8 Stream API features
 * Used throughout the JavaCart application for data processing
 */
public class Java8StreamExamples {
    
    public static final Predicate<Product> IN_STOCK = product -> 
        product.getStockQuantity() != null && product.getStockQuantity() > 0;
    
    public static final Predicate<Product> EXPENSIVE = product -> 
        product.getPrice().compareTo(BigDecimal.valueOf(100)) > 0;
    
    public static final Function<List<Cart>, BigDecimal> CALCULATE_TOTAL = cartItems ->
        cartItems.stream()
            .map(Cart::getTotalPrice)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    
    public static final Consumer<Product> PRODUCT_LOGGER = product ->
        System.out.println("Processing: " + product.getName());
    
    /**
     * Filter products by category using Stream API
     */
    public static List<Product> filterByCategory(List<Product> products, String category) {
        return products.stream()
            .filter(product -> product.getCategory().equalsIgnoreCase(category))
            .filter(IN_STOCK)
            .peek(PRODUCT_LOGGER)
            .collect(Collectors.toList());
    }
    
    /**
     * Search products with multiple criteria
     */
    public static List<Product> searchProducts(List<Product> products, String searchTerm) {
        return products.stream()
            .filter(product -> product.matchesSearchTerm(searchTerm))
            .sorted(Comparator.comparing(Product::getName))
            .collect(Collectors.toList());
    }
    
    /**
     * Get products grouped by category
     */
    public static Map<String, List<Product>> groupByCategory(List<Product> products) {
        return products.stream()
            .collect(Collectors.groupingBy(Product::getCategory));
    }
    
    /**
     * Get price statistics for products
     */
    public static DoubleSummaryStatistics getPriceStatistics(List<Product> products) {
        return products.stream()
            .mapToDouble(product -> product.getPrice().doubleValue())
            .summaryStatistics();
    }
    
    /**
     * Find top N expensive products
     */
    public static List<Product> getTopExpensiveProducts(List<Product> products, int limit) {
        return products.stream()
            .sorted(Comparator.comparing(Product::getPrice).reversed())
            .limit(limit)
            .collect(Collectors.toList());
    }
    
    /**
     * Check if any product matches criteria
     */
    public static boolean hasProductsInCategory(List<Product> products, String category) {
        return products.stream()
            .anyMatch(product -> product.getCategory().equalsIgnoreCase(category));
    }
    
    /**
     * Get unique categories
     */
    public static Set<String> getUniqueCategories(List<Product> products) {
        return products.stream()
            .map(Product::getCategory)
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());
    }
    
    /**
     * Calculate cart total using method reference
     */
    public static BigDecimal calculateCartTotal(List<Cart> cartItems) {
        return cartItems.stream()
            .map(Cart::getTotalPrice)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    /**
     * Filter and transform cart items
     */
    public static List<String> getCartItemNames(List<Cart> cartItems) {
        return cartItems.stream()
            .map(Cart::getProduct)
            .filter(Optional::isPresent)
            .map(Optional::get)
            .map(Product::getName)
            .collect(Collectors.toList());
    }
    
    /**
     * Parallel processing example for large datasets
     */
    public static long countExpensiveProducts(List<Product> products, BigDecimal threshold) {
        return products.parallelStream()
            .filter(product -> product.getPrice().compareTo(threshold) > 0)
            .count();
    }
    
    /**
     * Custom collector example
     */
    public static String getProductSummary(List<Product> products) {
        return products.stream()
            .map(Product::getName)
            .collect(Collectors.joining(", ", "Products: [", "]"));
    }
}
