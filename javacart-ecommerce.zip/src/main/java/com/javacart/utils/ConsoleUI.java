package com.javacart.utils;

import com.javacart.models.*;
import com.javacart.services.*;
import com.javacart.services.impl.*;
import com.javacart.exceptions.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.Collections;

public class ConsoleUI {
    private final Scanner scanner = new Scanner(System.in);
    
    private String repeat(String str, int count) {
        return String.join("", Collections.nCopies(count, str));
    }
    
    public void handleLogin(AuthService authService) {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        
        try {
            User user = authService.login(username, password);
            System.out.println("Login successful! Welcome, " + user.getUsername());
        } catch (UserNotFoundException e) {
            System.out.println("Login failed: " + e.getMessage());
        }
    }
    
    public void handleRegistration(AuthService authService) {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        System.out.print("Role (ADMIN/CUSTOMER): ");
        String role = scanner.nextLine().toUpperCase();
        
        if (!role.equals("ADMIN") && !role.equals("CUSTOMER")) {
            role = "CUSTOMER";
        }
        
        User user = authService.register(username, email, password, role);
        if (user != null) {
            System.out.println("Registration successful! Please login.");
        } else {
            System.out.println("Registration failed. Username or email might already exist.");
        }
    }
    
    public void displayProducts(List<Product> products) {
        if (products.isEmpty()) {
            System.out.println("No products found.");
            return;
        }
        
        System.out.println("\n=== Products ===");
        System.out.printf("%-5s %-20s %-15s %-15s %-10s%n", "ID", "Name", "Category", "Price", "Stock");
        System.out.println(repeat("-", 70));
        
        products.forEach(product -> 
            System.out.printf("%-5d %-20s %-15s $%-14.2f %-10d%n",
                product.getId(), 
                product.getName().length() > 20 ? product.getName().substring(0, 17) + "..." : product.getName(),
                product.getCategory(),
                product.getPrice(),
                product.getStockQuantity())
        );
    }
    
    public void handleBrowseProducts(ProductService productService) {
        System.out.println("\n1. View All Products");
        System.out.println("2. Filter by Category");
        System.out.println("3. Filter by Price Range");
        System.out.println("4. Sort by Price (Low to High)");
        System.out.println("5. Sort by Price (High to Low)");
        System.out.println("6. Sort by Name");
        System.out.print("Choose option: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine();
        
        switch (choice) {
            case 1:
                displayProducts(productService.getAllProducts());
                break;
            case 2:
                System.out.print("Enter category: ");
                String category = scanner.nextLine();
                displayProducts(productService.getProductsByCategory(category));
                break;
            case 3:
                System.out.print("Enter minimum price: ");
                BigDecimal minPrice = scanner.nextBigDecimal();
                System.out.print("Enter maximum price: ");
                BigDecimal maxPrice = scanner.nextBigDecimal();
                scanner.nextLine();
                displayProducts(productService.getProductsByPriceRange(minPrice, maxPrice));
                break;
            case 4:
                displayProducts(productService.getProductsSortedByPrice(true));
                break;
            case 5:
                displayProducts(productService.getProductsSortedByPrice(false));
                break;
            case 6:
                displayProducts(productService.getProductsSortedByName());
                break;
            default:
                System.out.println("Invalid option!");
        }
    }
    
    public void handleSearchProducts(ProductService productService) {
        System.out.print("Enter search keyword: ");
        String keyword = scanner.nextLine();
        
        List<Product> results = productService.searchProducts(keyword);
        System.out.println("\nSearch results for: " + keyword);
        displayProducts(results);
    }
    
    public void handleAddProduct(ProductService productService) {
        System.out.print("Product name: ");
        String name = scanner.nextLine();
        System.out.print("Description: ");
        String description = scanner.nextLine();
        System.out.print("Price: ");
        BigDecimal price = scanner.nextBigDecimal();
        scanner.nextLine();
        System.out.print("Category: ");
        String category = scanner.nextLine();
        System.out.print("Stock quantity: ");
        int stock = scanner.nextInt();
        scanner.nextLine();
        
        Product product = new Product(name, description, price, category, stock);
        Product savedProduct = productService.addProduct(product);
        
        if (savedProduct.getId() != null) {
            System.out.println("Product added successfully with ID: " + savedProduct.getId());
        } else {
            System.out.println("Failed to add product.");
        }
    }
    
    public void handleUpdateProduct(ProductService productService) {
        System.out.print("Enter product ID to update: ");
        Long id = scanner.nextLong();
        scanner.nextLine();
        
        try {
            Product product = productService.getProductById(id);
            System.out.println("Current product: " + product);
            
            System.out.print("New name (current: " + product.getName() + "): ");
            String name = scanner.nextLine();
            if (!name.trim().isEmpty()) {
                product.setName(name);
            }
            
            System.out.print("New price (current: $" + product.getPrice() + "): ");
            String priceStr = scanner.nextLine();
            if (!priceStr.trim().isEmpty()) {
                product.setPrice(new BigDecimal(priceStr));
            }
            
            System.out.print("New stock (current: " + product.getStockQuantity() + "): ");
            String stockStr = scanner.nextLine();
            if (!stockStr.trim().isEmpty()) {
                product.setStockQuantity(Integer.parseInt(stockStr));
            }
            
            productService.updateProduct(product);
            System.out.println("Product updated successfully!");
        } catch (ProductNotFoundException e) {
            System.out.println("Product not found: " + e.getMessage());
        }
    }
    
    public void handleDeleteProduct(ProductService productService) {
        System.out.print("Enter product ID to delete: ");
        Long id = scanner.nextLong();
        scanner.nextLine();
        
        try {
            productService.deleteProduct(id);
            System.out.println("Product deleted successfully!");
        } catch (ProductNotFoundException e) {
            System.out.println("Product not found: " + e.getMessage());
        }
    }
    
    public void displayCart(CartService cartService, Long userId) {
        List<Cart> cartItems = cartService.getCartItems(userId);
        
        if (cartItems.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        
        System.out.println("\n=== Your Cart ===");
        System.out.printf("%-20s %-10s %-10s %-10s%n", "Product", "Price", "Quantity", "Total");
        System.out.println(repeat("-", 55));
        
        BigDecimal grandTotal = BigDecimal.ZERO;
        for (Cart item : cartItems) {
            Product product = item.getProduct().orElse(null);
            if (product != null) {
                System.out.printf("%-20s $%-9.2f %-10d $%-9.2f%n",
                    product.getName().length() > 20 ? 
                        product.getName().substring(0, 17) + "..." : product.getName(),
                    product.getPrice(),
                    item.getQuantity(),
                    item.getTotalPrice());
            }
            grandTotal = grandTotal.add(item.getTotalPrice());
        }
        
        System.out.println(repeat("-", 55));
        System.out.printf("Grand Total: $%.2f%n", grandTotal);
        System.out.printf("Total Items: %d%n", cartService.getCartItemCount(userId));
    }
    
    public void handleAddToCart(CartService cartService, ProductService productService, Long userId) {
        displayProducts(productService.getAllProducts());
        
        System.out.print("Enter product ID to add to cart: ");
        Long productId = scanner.nextLong();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();
        
        try {
            cartService.addToCart(userId, productId, quantity);
            System.out.println("Product added to cart successfully!");
        } catch (ProductNotFoundException e) {
            System.out.println("Product not found: " + e.getMessage());
        } catch (OutOfStockException e) {
            System.out.println("Out of stock: " + e.getMessage());
        }
    }
    
    public void handleRemoveFromCart(CartService cartService, Long userId) {
        displayCart(cartService, userId);
        
        System.out.print("Enter product ID to remove from cart: ");
        Long productId = scanner.nextLong();
        scanner.nextLine();
        
        cartService.removeFromCart(userId, productId);
        System.out.println("Product removed from cart!");
    }
    
    public void handleCheckout(CartService cartService, OrderService orderService, Long userId) {
        displayCart(cartService, userId);
        
        if (cartService.getCartItemCount(userId) == 0) {
            System.out.println("Cannot checkout with empty cart.");
            return;
        }
        
        System.out.print("Proceed with checkout? (y/n): ");
        String confirm = scanner.nextLine();
        
        if (confirm.toLowerCase().startsWith("y")) {
            try {
                Order order = orderService.createOrder(userId);
                System.out.println("Order created successfully!");
                System.out.println("Order ID: " + order.getId());
                System.out.println("Total Amount: $" + order.getTotalAmount());
                System.out.println("Status: " + order.getStatus());
            } catch (OutOfStockException e) {
                System.out.println("Checkout failed: " + e.getMessage());
            }
        }
    }
    
    public void displayOrders(List<Order> orders) {
        if (orders.isEmpty()) {
            System.out.println("No orders found.");
            return;
        }
        
        System.out.println("\n=== Orders ===");
        for (Order order : orders) {
            System.out.printf("Order #%d - Total: $%.2f - Status: %s - Date: %s%n",
                order.getId(), order.getTotalAmount(), order.getStatus(), order.getCreatedAt());
            
            if (order.getOrderItems() != null && !order.getOrderItems().isEmpty()) {
                System.out.println("  Items:");
                for (OrderItem item : order.getOrderItems()) {
                    System.out.printf("    - %s (Qty: %d, Price: $%.2f)%n",
                        item.getProduct().getName(), item.getQuantity(), item.getTotalPrice());
                }
            }
            System.out.println();
        }
    }
    
    public void simulateConcurrentOrders(OrderService orderService, ProductService productService) {
        System.out.println("Simulating concurrent orders...");
        
        ExecutorService executor = Executors.newFixedThreadPool(5);
        
        // Create sample orders concurrently
        for (int i = 0; i < 10; i++) {
            final int orderNum = i + 1;
            executor.submit(() -> {
                try {
                    System.out.println("Processing concurrent order #" + orderNum);
                    // Simulate order processing with user ID 2 (customer)
                    orderService.processOrderConcurrently(2L);
                    System.out.println("Concurrent order #" + orderNum + " completed");
                } catch (Exception e) {
                    System.out.println("Concurrent order #" + orderNum + " failed: " + e.getMessage());
                }
            });
        }
        
        executor.shutdown();
        try {
            executor.awaitTermination(30, TimeUnit.SECONDS);
            System.out.println("All concurrent orders processed!");
        } catch (InterruptedException e) {
            System.out.println("Concurrent order simulation interrupted");
        }
    }
}
