package com.javacart.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/javacart";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "password";
    
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC Driver not found", e);
        }
    }
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
    
    public static void initializeDatabase() throws SQLException {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create database if not exists
            stmt.execute("CREATE DATABASE IF NOT EXISTS javacart");
            stmt.execute("USE javacart");
            
            // Create tables
            createTables(stmt);
            
            // Insert sample data
            insertSampleData(stmt);
            
            System.out.println("Database initialized successfully!");
        }
    }
    
    private static void createTables(Statement stmt) throws SQLException {
        // Users table
        stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "username VARCHAR(50) UNIQUE NOT NULL," +
            "email VARCHAR(100) UNIQUE NOT NULL," +
            "password VARCHAR(255) NOT NULL," +
            "role ENUM('ADMIN', 'CUSTOMER') DEFAULT 'CUSTOMER'," +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ")");
        
        // Products table
        stmt.execute("CREATE TABLE IF NOT EXISTS products (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "name VARCHAR(100) NOT NULL," +
            "description TEXT," +
            "price DECIMAL(10, 2) NOT NULL," +
            "category VARCHAR(50) NOT NULL," +
            "stock_quantity INT NOT NULL DEFAULT 0," +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" +
            ")");
        
        // Cart table
        stmt.execute("CREATE TABLE IF NOT EXISTS cart (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "user_id BIGINT NOT NULL," +
            "product_id BIGINT NOT NULL," +
            "quantity INT NOT NULL DEFAULT 1," +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE," +
            "FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE," +
            "UNIQUE KEY unique_user_product (user_id, product_id)" +
            ")");
        
        // Orders table
        stmt.execute("CREATE TABLE IF NOT EXISTS orders (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "user_id BIGINT NOT NULL," +
            "total_amount DECIMAL(10, 2) NOT NULL," +
            "status ENUM('PENDING', 'PROCESSING', 'COMPLETED', 'CANCELLED') DEFAULT 'PENDING'," +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE" +
            ")");
        
        // Order items table
        stmt.execute("CREATE TABLE IF NOT EXISTS order_items (" +
            "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "order_id BIGINT NOT NULL," +
            "product_id BIGINT NOT NULL," +
            "quantity INT NOT NULL," +
            "unit_price DECIMAL(10, 2) NOT NULL," +
            "FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE," +
            "FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE" +
            ")");
    }
    
    private static void insertSampleData(Statement stmt) throws SQLException {
        // Insert admin user
        stmt.execute("INSERT IGNORE INTO users (username, email, password, role) " +
            "VALUES ('admin', 'admin@javacart.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN')");
        
        // Insert sample customer
        stmt.execute("INSERT IGNORE INTO users (username, email, password, role) " +
            "VALUES ('customer', 'customer@javacart.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CUSTOMER')");
        
        // Insert sample products
        stmt.execute("INSERT IGNORE INTO products (name, description, price, category, stock_quantity) VALUES " +
            "('iPhone 15', 'Latest Apple smartphone with advanced features', 999.99, 'Electronics', 50)," +
            "('Samsung Galaxy S24', 'Premium Android smartphone', 899.99, 'Electronics', 30)," +
            "('MacBook Pro', 'High-performance laptop for professionals', 1999.99, 'Electronics', 20)," +
            "('Nike Air Max', 'Comfortable running shoes', 129.99, 'Footwear', 100)," +
            "('Adidas Ultraboost', 'Premium running shoes with boost technology', 179.99, 'Footwear', 75)," +
            "('Levi\\'s 501 Jeans', 'Classic straight-fit jeans', 59.99, 'Clothing', 200)," +
            "('The Great Gatsby', 'Classic American novel by F. Scott Fitzgerald', 12.99, 'Books', 150)," +
            "('Wireless Headphones', 'Noise-cancelling Bluetooth headphones', 199.99, 'Electronics', 80)," +
            "('Coffee Maker', 'Programmable drip coffee maker', 79.99, 'Home & Kitchen', 40)," +
            "('Yoga Mat', 'Non-slip exercise mat for yoga and fitness', 29.99, 'Sports', 120)");
    }
}
