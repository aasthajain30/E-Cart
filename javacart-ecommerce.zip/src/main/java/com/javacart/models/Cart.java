package com.javacart.models;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

public class Cart {
    private Long id;
    private Long userId;
    private Long productId;
    private Integer quantity;
    private LocalDateTime createdAt;
    
    // For joined queries
    private Product product;
    
    // Constructors
    public Cart() {}
    
    public Cart(Long userId, Long productId, Integer quantity) {
        this.userId = userId;
        this.productId = productId;
        this.quantity = quantity;
        this.createdAt = LocalDateTime.now();
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public Optional<Product> getProduct() { 
        return Optional.ofNullable(product); 
    }
    public void setProduct(Product product) { this.product = product; }
    
    public BigDecimal getTotalPrice() {
        return getProduct()
            .map(Product::getPrice)
            .filter(Objects::nonNull)
            .map(price -> price.multiply(BigDecimal.valueOf(
                Optional.ofNullable(quantity).orElse(0))))
            .orElse(BigDecimal.ZERO);
    }
    
    public boolean hasValidQuantity() {
        return quantity != null && quantity > 0;
    }
    
    public boolean isProductAvailable() {
        return getProduct()
            .map(Product::isInStock)
            .orElse(false);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Cart cart = (Cart) obj;
        return Objects.equals(id, cart.id) &&
               Objects.equals(userId, cart.userId) &&
               Objects.equals(productId, cart.productId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, userId, productId);
    }
    
    @Override
    public String toString() {
        return String.format("Cart{productId=%d, quantity=%d, totalPrice=$%.2f}", 
                           productId, quantity, getTotalPrice());
    }
}
