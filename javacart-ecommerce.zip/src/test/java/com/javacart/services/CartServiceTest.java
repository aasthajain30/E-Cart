package com.javacart.services;

import com.javacart.models.Cart;
import com.javacart.services.impl.CartServiceImpl;
import com.javacart.exceptions.OutOfStockException;
import com.javacart.exceptions.ProductNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CartServiceTest {
    private CartService cartService;
    private final Long testUserId = 2L; // customer user
    
    @BeforeEach
    void setUp() {
        cartService = new CartServiceImpl();
        // Clear cart before each test
        cartService.clearCart(testUserId);
    }
    
    @Test
    void testAddToCart() {
        assertDoesNotThrow(() -> {
            cartService.addToCart(testUserId, 1L, 2);
        });
        
        List<Cart> cartItems = cartService.getCartItems(testUserId);
        assertEquals(1, cartItems.size());
        assertEquals(2, cartItems.get(0).getQuantity());
    }
    
    @Test
    void testAddToCartInvalidProduct() {
        assertThrows(ProductNotFoundException.class, () -> {
            cartService.addToCart(testUserId, 999L, 1);
        });
    }
    
    @Test
    void testRemoveFromCart() {
        // First add an item
        assertDoesNotThrow(() -> {
            cartService.addToCart(testUserId, 1L, 1);
        });
        
        // Then remove it
        cartService.removeFromCart(testUserId, 1L);
        
        List<Cart> cartItems = cartService.getCartItems(testUserId);
        assertTrue(cartItems.isEmpty());
    }
    
    @Test
    void testGetCartTotal() {
        assertDoesNotThrow(() -> {
            cartService.addToCart(testUserId, 1L, 2);
            cartService.addToCart(testUserId, 2L, 1);
        });
        
        BigDecimal total = cartService.getCartTotal(testUserId);
        assertTrue(total.compareTo(BigDecimal.ZERO) > 0);
    }
    
    @Test
    void testGetCartItemCount() {
        assertDoesNotThrow(() -> {
            cartService.addToCart(testUserId, 1L, 2);
            cartService.addToCart(testUserId, 2L, 3);
        });
        
        int count = cartService.getCartItemCount(testUserId);
        assertEquals(5, count); // 2 + 3
    }
    
    @Test
    void testClearCart() {
        assertDoesNotThrow(() -> {
            cartService.addToCart(testUserId, 1L, 2);
            cartService.addToCart(testUserId, 2L, 1);
        });
        
        cartService.clearCart(testUserId);
        
        List<Cart> cartItems = cartService.getCartItems(testUserId);
        assertTrue(cartItems.isEmpty());
    }
}
