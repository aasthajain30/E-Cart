package com.javacart.services;

import com.javacart.models.Product;
import com.javacart.services.impl.ProductServiceImpl;
import com.javacart.exceptions.ProductNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ProductServiceTest {
    private ProductService productService;
    
    @BeforeEach
    void setUp() {
        productService = new ProductServiceImpl();
    }
    
    @Test
    void testGetAllProducts() {
        List<Product> products = productService.getAllProducts();
        assertNotNull(products);
        assertFalse(products.isEmpty());
    }
    
    @Test
    void testSearchProducts() {
        List<Product> results = productService.searchProducts("iPhone");
        assertNotNull(results);
        assertTrue(results.stream().anyMatch(p -> p.getName().toLowerCase().contains("iphone")));
    }
    
    @Test
    void testGetProductsByCategory() {
        List<Product> electronics = productService.getProductsByCategory("Electronics");
        assertNotNull(electronics);
        assertTrue(electronics.stream().allMatch(p -> p.getCategory().equals("Electronics")));
    }
    
    @Test
    void testGetProductsByPriceRange() {
        BigDecimal minPrice = new BigDecimal("50.00");
        BigDecimal maxPrice = new BigDecimal("100.00");
        
        List<Product> products = productService.getProductsByPriceRange(minPrice, maxPrice);
        assertNotNull(products);
        assertTrue(products.stream().allMatch(p -> 
            p.getPrice().compareTo(minPrice) >= 0 && p.getPrice().compareTo(maxPrice) <= 0));
    }
    
    @Test
    void testGetProductsSortedByPrice() {
        List<Product> ascending = productService.getProductsSortedByPrice(true);
        List<Product> descending = productService.getProductsSortedByPrice(false);
        
        assertNotNull(ascending);
        assertNotNull(descending);
        
        // Check if ascending order is correct
        for (int i = 1; i < ascending.size(); i++) {
            assertTrue(ascending.get(i-1).getPrice().compareTo(ascending.get(i).getPrice()) <= 0);
        }
        
        // Check if descending order is correct
        for (int i = 1; i < descending.size(); i++) {
            assertTrue(descending.get(i-1).getPrice().compareTo(descending.get(i).getPrice()) >= 0);
        }
    }
    
    @Test
    void testGetProductsSortedByName() {
        List<Product> sorted = productService.getProductsSortedByName();
        assertNotNull(sorted);
        
        // Check if sorted by name
        for (int i = 1; i < sorted.size(); i++) {
            assertTrue(sorted.get(i-1).getName().compareTo(sorted.get(i).getName()) <= 0);
        }
    }
}
