package com.javacart.utils;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PasswordUtilTest {
    
    @Test
    void testHashPassword() {
        String password = "testPassword123";
        String hashedPassword = PasswordUtil.hashPassword(password);
        
        assertNotNull(hashedPassword);
        assertNotEquals(password, hashedPassword);
        assertTrue(hashedPassword.length() > 0);
    }
    
    @Test
    void testVerifyPassword() {
        String password = "testPassword123";
        String hashedPassword = PasswordUtil.hashPassword(password);
        
        assertTrue(PasswordUtil.verifyPassword(password, hashedPassword));
        assertFalse(PasswordUtil.verifyPassword("wrongPassword", hashedPassword));
    }
    
    @Test
    void testHashPasswordUniqueness() {
        String password = "testPassword123";
        String hash1 = PasswordUtil.hashPassword(password);
        String hash2 = PasswordUtil.hashPassword(password);
        
        // Hashes should be different due to salt
        assertNotEquals(hash1, hash2);
        
        // But both should verify correctly
        assertTrue(PasswordUtil.verifyPassword(password, hash1));
        assertTrue(PasswordUtil.verifyPassword(password, hash2));
    }
    
    @Test
    void testVerifyPasswordWithInvalidHash() {
        assertFalse(PasswordUtil.verifyPassword("password", "invalidHash"));
        assertFalse(PasswordUtil.verifyPassword("password", ""));
        assertFalse(PasswordUtil.verifyPassword("password", null));
    }
}
