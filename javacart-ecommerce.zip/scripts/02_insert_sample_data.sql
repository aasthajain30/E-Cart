-- Insert Sample Data for JavaCart

-- Insert default users (password is 'password' for both)
INSERT IGNORE INTO users (username, email, password, role) VALUES
('admin', 'admin@javacart.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN'),
('customer', 'customer@javacart.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CUSTOMER'),
('john_doe', 'john@example.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CUSTOMER'),
('jane_smith', 'jane@example.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'CUSTOMER');

-- Insert sample products
INSERT IGNORE INTO products (name, description, price, category, stock_quantity) VALUES
-- Electronics
('iPhone 15 Pro', 'Latest Apple smartphone with titanium design and A17 Pro chip', 999.99, 'Electronics', 50),
('Samsung Galaxy S24 Ultra', 'Premium Android smartphone with S Pen and AI features', 1199.99, 'Electronics', 30),
('MacBook Pro 14"', 'High-performance laptop with M3 chip for professionals', 1999.99, 'Electronics', 20),
('iPad Air', 'Versatile tablet perfect for work and creativity', 599.99, 'Electronics', 40),
('AirPods Pro', 'Wireless earbuds with active noise cancellation', 249.99, 'Electronics', 100),
('Dell XPS 13', 'Ultra-portable Windows laptop with premium build', 1299.99, 'Electronics', 25),
('Sony WH-1000XM5', 'Industry-leading noise cancelling headphones', 399.99, 'Electronics', 60),
('Nintendo Switch OLED', 'Hybrid gaming console with vibrant OLED screen', 349.99, 'Electronics', 35),

-- Footwear
('Nike Air Max 270', 'Comfortable lifestyle sneakers with Max Air cushioning', 129.99, 'Footwear', 100),
('Adidas Ultraboost 22', 'Premium running shoes with responsive Boost midsole', 179.99, 'Footwear', 75),
('Converse Chuck Taylor All Star', 'Classic canvas sneakers, timeless style', 59.99, 'Footwear', 150),
('Vans Old Skool', 'Iconic skate shoes with signature side stripe', 64.99, 'Footwear', 120),
('New Balance 990v5', 'Premium made-in-USA running shoes', 184.99, 'Footwear', 50),

-- Clothing
('Levi\'s 501 Original Jeans', 'Classic straight-fit jeans, the original blue jean', 59.99, 'Clothing', 200),
('Nike Dri-FIT T-Shirt', 'Moisture-wicking athletic t-shirt', 24.99, 'Clothing', 300),
('Patagonia Better Sweater', 'Cozy fleece jacket made from recycled materials', 99.99, 'Clothing', 80),
('Champion Reverse Weave Hoodie', 'Classic heavyweight hoodie with iconic logo', 64.99, 'Clothing', 150),
('Uniqlo Heattech Long Sleeve', 'Thermal base layer for cold weather', 19.99, 'Clothing', 250),

-- Books
('The Great Gatsby', 'Classic American novel by F. Scott Fitzgerald', 12.99, 'Books', 150),
('To Kill a Mockingbird', 'Timeless story of justice and morality by Harper Lee', 13.99, 'Books', 120),
('1984', 'Dystopian masterpiece by George Orwell', 14.99, 'Books', 100),
('Pride and Prejudice', 'Beloved romance novel by Jane Austen', 11.99, 'Books', 180),
('The Catcher in the Rye', 'Coming-of-age classic by J.D. Salinger', 13.49, 'Books', 90),

-- Home & Kitchen
('Instant Pot Duo 7-in-1', 'Multi-functional electric pressure cooker', 79.99, 'Home & Kitchen', 40),
('KitchenAid Stand Mixer', 'Professional-grade stand mixer for baking', 379.99, 'Home & Kitchen', 25),
('Ninja Blender', 'High-powered blender for smoothies and food prep', 99.99, 'Home & Kitchen', 60),
('Cuisinart Coffee Maker', 'Programmable drip coffee maker with thermal carafe', 89.99, 'Home & Kitchen', 45),
('Lodge Cast Iron Skillet', 'Pre-seasoned 10-inch cast iron pan', 34.99, 'Home & Kitchen', 80),

-- Sports & Outdoors
('Yoga Mat Premium', 'Non-slip exercise mat with alignment lines', 29.99, 'Sports', 120),
('Resistance Bands Set', 'Complete set of resistance bands for home workouts', 24.99, 'Sports', 200),
('Dumbbell Set Adjustable', 'Space-saving adjustable dumbbells 5-50 lbs', 299.99, 'Sports', 30),
('Hydro Flask Water Bottle', 'Insulated stainless steel water bottle 32oz', 44.99, 'Sports', 150),
('Coleman Camping Tent', '4-person dome tent for outdoor adventures', 89.99, 'Sports', 40);
